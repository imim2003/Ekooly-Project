<!DOCTYPE html>
<?php include 'config.php'?>
<html>
    <head>
        <title>eKooly</title>
        <meta charset="UTF-8">
        <meta name="keywords" content="job portal">
        <meta name="description" content="find jobs">
        <link href="C:\Users\archi\OneDrive\Desktop\profile\ele2.css" rel="stylesheet">
        <style>th {border:1px solid black;padding:10px;border-collapse:separate;}</style>
        <style>th,a{background-color:rgb(255,69,0);color:black;} a:hover{color: blue;font-size: smaller;}
        th:hover{color: gold;} </style>
        <style>.emo:hover{width:"auto"; height:90px;}</style>
        <style>.em:hover{width:"auto"; height:90px;} a{text-decoration:none;}</style>
        
       <div id="ima"> <h1 style=" color: rgb(255,69,0);"> <pre>Welcome to eKOOLY!<a href=/login.php><img class="emo"align="right" src=https://thumbs.dreamstime.com/b/login-isolated-premium-orange-round-button-abstract-illustration-login-premium-orange-round-button-105916797.jpg width="auto" height="60"/></a> <a href=\signup.php><img class="em" align="right" src=https://thumbs.dreamstime.com/b/sign-up-member-icon-special-glassy-orange-round-button-sign-up-member-icon-isolated-special-glassy-orange-round-button-abstract-142395621.jpg width="auto" height="60"/></a></pre></h1>
    
    </head>
    
        <header>
            <div id= hello class="spec">
            
            <span id="el3">
            
             <br>
            <table>
                
                <tbody>
                    
                    <tr>
                       
                        
                        <th><a href=/Ecoolie.php >Home</a> </th> 
                        <th><a href=/payment.php>Book a coolie</a></th>
                        <th><a href=/contact.php>Contact us</a></th>
                       
                    </tr>
                </tbody>
            
              </table>
           
            </span>           
        </div>    
                
                
                
         
        <div id="intro">
             
        </div>
        </header>

        <section>
           <div id="intro">
           <h2 style="color:rgb(255,69,0)">About</h2>
              - <b>eKooly is a smart mobility solution provider,dedicated to railway pick and drop.<br>
              - Our website provides sahayaks(coolies)to railway passengers through online booking <br>
              
           </div>
        </section>   
         
           <footer class="photo">
               <p> </p>
               <img src="cools.jpg" width="auto" height="450"/>
           
          </footer>
          
    </body>
 </html>